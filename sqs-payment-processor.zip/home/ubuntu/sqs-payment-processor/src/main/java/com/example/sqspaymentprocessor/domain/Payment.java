package com.example.sqspaymentprocessor.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

/**
 * Representa um evento de pagamento a ser processado.
 * Utiliza Lombok para reduzir código boilerplate (getters, setters, construtores, etc.).
 */
@Data // Gera getters, setters, toString, equals, hashCode
@NoArgsConstructor // Gera construtor sem argumentos (necessário para deserialização JSON)
@AllArgsConstructor // Gera construtor com todos os argumentos
public class Payment {

    private UUID paymentId; // Identificador único do pagamento
    private String orderId; // Identificador do pedido associado
    private BigDecimal amount; // Valor do pagamento
    private String currency; // Moeda (e.g., "BRL", "USD")
    private String paymentMethod; // Método de pagamento (e.g., "CREDIT_CARD", "PIX")
    private Instant timestamp; // Momento em que o evento de pagamento foi gerado
    private String status; // Status inicial (e.g., "PENDING")

    /**
     * Método de fábrica para criar um novo pagamento pendente.
     *
     * @param orderId Identificador do pedido.
     * @param amount Valor do pagamento.
     * @param currency Moeda.
     * @param paymentMethod Método de pagamento.
     * @return Uma nova instância de Payment com status PENDING.
     */
    public static Payment createPending(String orderId, BigDecimal amount, String currency, String paymentMethod) {
        return new Payment(
                UUID.randomUUID(),
                orderId,
                amount,
                currency,
                paymentMethod,
                Instant.now(),
                "PENDING"
        );
    }
}

