package com.example.sqspaymentprocessor.producer;

import com.example.sqspaymentprocessor.domain.Payment;
import io.awspring.cloud.sqs.operations.SendResult;
import io.awspring.cloud.sqs.operations.SqsTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * Componente responsável por enviar mensagens de pagamento para a fila SQS.
 *
 * Utiliza SqsTemplate para abstrair a comunicação com o SQS.
 */
@Component
public class PaymentProducer {

    private static final Logger log = LoggerFactory.getLogger(PaymentProducer.class);

    private final SqsTemplate sqsTemplate;
    private final String paymentQueueName;

    /**
     * Construtor que injeta o SqsTemplate e o nome da fila de pagamento.
     *
     * @param sqsTemplate      O template para interagir com SQS.
     * @param paymentQueueName O nome da fila SQS de pagamentos, injetado de application.yml.
     */
    public PaymentProducer(SqsTemplate sqsTemplate, @Value("${app.queues.payment-processing}") String paymentQueueName) {
        this.sqsTemplate = sqsTemplate;
        this.paymentQueueName = paymentQueueName;
        log.info("PaymentProducer configurado para enviar mensagens para a fila: {}", this.paymentQueueName);
    }

    /**
     * Envia um único evento de pagamento para a fila SQS.
     *
     * @param payment O objeto de pagamento a ser enviado.
     * @return Um CompletableFuture que será completado com o resultado do envio.
     */
    public CompletableFuture<SendResult<Payment>> sendPayment(Payment payment) {
        log.debug("Enviando pagamento único: {}", payment.getPaymentId());
        return sqsTemplate.sendAsync(paymentQueueName, payment);
    }

    /**
     * Envia uma lista de eventos de pagamento em lote para a fila SQS.
     * Utiliza a operação sendManyAsync do SqsTemplate para otimizar o envio em lote.
     *
     * @param payments Coleção de objetos de pagamento a serem enviados.
     * @return Um CompletableFuture que será completado com os resultados do envio em lote.
     */
    public CompletableFuture<SendResult.Batch<Payment>> sendPaymentsBatch(Collection<Payment> payments) {
        if (payments == null || payments.isEmpty()) {
            log.warn("Tentativa de enviar um lote vazio de pagamentos.");
            return CompletableFuture.completedFuture(null); // Ou lançar exceção, dependendo da lógica
        }
        log.info("Enviando lote de {} pagamentos...", payments.size());

        // O SqsTemplate lida com a divisão em lotes de 10 mensagens automaticamente se necessário
        // e serializa os objetos Payment para JSON por padrão (se Jackson estiver no classpath).
        List<Message<Payment>> messages = payments.stream()
                .map(payment -> MessageBuilder.withPayload(payment).build())
                .collect(Collectors.toList());

        return sqsTemplate.sendManyAsync(paymentQueueName, messages);
    }
}

