package com.example.sqspaymentprocessor.config;

import io.awspring.cloud.sqs.config.SqsListenerConfigurer;
import io.awspring.cloud.sqs.config.SqsMessageListenerContainerFactory;
import io.awspring.cloud.sqs.operations.SqsTemplate;
import io.awspring.cloud.sqs.operations.SqsTemplateParameters;
import io.awspring.cloud.sqs.support.converter.SqsMessagingMessageConverter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.sqs.SqsAsyncClient;
import software.amazon.awssdk.services.sqs.SqsAsyncClientBuilder;

import java.net.URI;
import java.time.Duration;

/**
 * Configuração do SQS para a aplicação Spring Boot.
 *
 * Define beans para o cliente SQS assíncrono, SqsTemplate para envio de mensagens,
 * e configura o listener para recebimento em lote.
 */
@Configuration
public class SqsConfig {

    private static final Logger log = LoggerFactory.getLogger(SqsConfig.class);

    // Injeta o endpoint do SQS (útil para LocalStack em testes)
    // O @Value permite que seja nulo se não definido no application.yml principal
    @Value("${spring.cloud.aws.sqs.endpoint:#{null}}")
    private String sqsEndpoint;

    @Value("${spring.cloud.aws.region.static:#{null}}")
    private String awsRegion;

    /**
     * Configura o SqsAsyncClient.
     * Em um ambiente AWS real, as credenciais e a região geralmente são detectadas automaticamente.
     * Para LocalStack, o endpoint precisa ser configurado.
     *
     * @param credentialsProvider Provedor de credenciais AWS (gerenciado pelo Spring Cloud AWS).
     * @return Instância configurada do SqsAsyncClient.
     */
    @Bean
    @Primary // Garante que este bean seja o SqsAsyncClient principal
    public SqsAsyncClient sqsAsyncClient(AwsCredentialsProvider credentialsProvider) {
        SqsAsyncClientBuilder builder = SqsAsyncClient.builder()
                .credentialsProvider(credentialsProvider);

        if (awsRegion != null && !awsRegion.isBlank()) {
            builder.region(Region.of(awsRegion));
            log.info("Configurando SQS Async Client para a região: {}", awsRegion);
        } else {
            // Tenta detectar a região automaticamente se não estiver definida
            log.warn("Região AWS não definida explicitamente em 'spring.cloud.aws.region.static'. Tentando detecção automática.");
        }

        if (sqsEndpoint != null && !sqsEndpoint.isBlank()) {
            log.info("Configurando SQS Async Client com endpoint customizado: {}", sqsEndpoint);
            builder.endpointOverride(URI.create(sqsEndpoint));
        }

        return builder.build();
    }

    /**
     * Configura o SqsTemplate para envio de mensagens.
     * Utiliza o SqsAsyncClient configurado e um conversor JSON.
     *
     * @param sqsAsyncClient O cliente SQS assíncrono.
     * @return Instância configurada do SqsTemplate.
     */
    @Bean
    public SqsTemplate sqsTemplate(SqsAsyncClient sqsAsyncClient) {
        // Configuração padrão do SqsTemplate é geralmente suficiente.
        // Customizações podem ser feitas aqui se necessário.
        return SqsTemplate.builder()
                .sqsAsyncClient(sqsAsyncClient)
                // Define um conversor para serializar/deserializar payloads como JSON
                // .messageConverter(...) // Se precisar de um ObjectMapper customizado
                .build();
    }

    /**
     * Configura a fábrica de containers de listener SQS.
     * Define configurações padrão para os listeners, como o SqsAsyncClient a ser usado.
     * As configurações do application.yml (como max-number-of-messages) são aplicadas aqui.
     *
     * @param sqsAsyncClient O cliente SQS assíncrono.
     * @return Fábrica de containers de listener configurada.
     */
    @Bean
    public SqsMessageListenerContainerFactory<Object> defaultSqsListenerContainerFactory(SqsAsyncClient sqsAsyncClient) {
        return SqsMessageListenerContainerFactory
                .builder()
                .sqsAsyncClient(sqsAsyncClient)
                // Configurações adicionais podem ser feitas aqui, se necessário,
                // complementando ou sobrescrevendo application.yml
                // .configure(options -> options.maxMessagesPerPoll(5)) // Exemplo
                .build();
    }

    // Opcional: Configuração fina do Listener (exemplo: definir um conversor específico)
    // @Bean
    // public SqsListenerConfigurer configurer(ObjectMapper objectMapper) {
    //     return registrar -> {
    //         var messageConverter = new SqsMessagingMessageConverter();
    //         messageConverter.setPayloadObjectMapper(objectMapper);
    //         registrar.setMessageConverter(messageConverter);
    //     };
    // }

}

