package com.example.sqspaymentprocessor.consumer;

import com.example.sqspaymentprocessor.domain.Payment;
import io.awspring.cloud.sqs.annotation.SqsListener;
import io.awspring.cloud.sqs.listener.acknowledgement.Acknowledgement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.Message;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Componente responsável por consumir mensagens de pagamento da fila SQS em lote.
 *
 * Utiliza a anotação @SqsListener para receber mensagens automaticamente.
 */
@Component
public class PaymentConsumer {

    private static final Logger log = LoggerFactory.getLogger(PaymentConsumer.class);

    /**
     * Processa um lote de mensagens de pagamento recebidas da fila SQS.
     *
     * A anotação @SqsListener configura este método para escutar a fila definida
     * em 'app.queues.payment-processing' no application.yml.
     * O Spring Cloud AWS automaticamente deserializa o corpo da mensagem JSON para objetos Payment.
     * A injeção de List<Message<Payment>> permite receber o lote completo.
     *
     * IMPORTANTE: O processamento em lote requer tratamento cuidadoso de erros.
     * Se uma exceção for lançada aqui sem tratamento, TODAS as mensagens no lote
     * retornarão para a fila após o Visibility Timeout (ou irão para a DLQ se configurada),
     * mesmo que algumas tenham sido processadas com sucesso.
     * Para alta performance e resiliência, implemente a lógica de processamento individual
     * dentro do loop e trate exceções por mensagem, potencialmente usando Acknowledgement
     * para confirmar mensagens processadas com sucesso individualmente (mais complexo).
     *
     * @param messages A lista de mensagens recebidas no lote.
     */
    @SqsListener(value = "${app.queues.payment-processing}") // Escuta a fila definida nas propriedades
    public void receivePaymentBatch(List<Message<Payment>> messages) {
        log.info("Recebido lote de {} mensagens de pagamento.", messages.size());

        // Simula o processamento de cada pagamento no lote
        for (Message<Payment> message : messages) {
            Payment payment = message.getPayload();
            try {
                log.debug("Processando pagamento ID: {}, Pedido ID: {}, Valor: {} {}",
                        payment.getPaymentId(), payment.getOrderId(), payment.getAmount(), payment.getCurrency());

                // Simula um tempo de processamento variável por pagamento
                long processingTimeMillis = 50 + (long) (Math.random() * 150); // Entre 50ms e 200ms
                TimeUnit.MILLISECONDS.sleep(processingTimeMillis);

                // Lógica de processamento real iria aqui:
                // - Validar pagamento
                // - Chamar serviço de pagamento externo
                // - Atualizar status no banco de dados
                // - Publicar evento de pagamento processado (SNS, Kafka, etc.)

                log.debug("Pagamento ID: {} processado com sucesso em {}ms.", payment.getPaymentId(), processingTimeMillis);

            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                log.error("Thread interrompida durante o processamento do pagamento ID: {}. Re-lançando exceção para não acusar recebimento.", payment.getPaymentId(), e);
                // Re-lançar ou tratar de forma que a mensagem não seja confirmada
                throw new RuntimeException("Processamento interrompido para pagamento " + payment.getPaymentId(), e);
            } catch (Exception e) {
                // Tratamento de erro para um pagamento específico
                log.error("Erro ao processar pagamento ID: {}. Detalhes: {}", payment.getPaymentId(), e.getMessage(), e);
                // DECISÃO CRÍTICA:
                // 1. Lançar a exceção: Faz com que TODO o lote retorne à fila (ou vá para DLQ).
                //    Simples, mas reprocessa mensagens já bem-sucedidas.
                // 2. Logar e continuar: Processa os demais, mas a mensagem com erro será
                //    removida da fila (ACK implícito ao final do método sem exceção).
                //    Pode levar à perda de mensagens se não houver DLQ ou tratamento externo.
                // 3. Usar Acknowledgement manual (requer configuração adicional): Permite ACK/NACK individual.
                //    Mais complexo, porém mais robusto para processamento parcial de lotes.

                // Para este exemplo, vamos lançar a exceção para demonstrar o comportamento padrão.
                // Em um cenário real, a escolha depende dos requisitos de negócio.
                throw new RuntimeException("Falha no processamento do pagamento " + payment.getPaymentId(), e);
            }
        }

        log.info("Lote de {} mensagens processado.", messages.size());
        // Se o método concluir sem exceções, todas as mensagens do lote são automaticamente confirmadas (ACK) e removidas da fila.
    }

    /*
    // Exemplo alternativo recebendo apenas os Payloads (menos informações, como headers SQS)
    @SqsListener(value = "${app.queues.payment-processing}")
    public void receivePaymentPayloadBatch(@Payload List<Payment> payments) {
        log.info("Recebido lote de {} payloads de pagamento.", payments.size());
        for (Payment payment : payments) {
            log.debug("Processando pagamento ID: {}", payment.getPaymentId());
            // ... lógica de processamento ...
        }
        log.info("Lote de {} payloads processado.", payments.size());
    }
    */

    /*
    // Exemplo com Acknowledgement manual (requer configuração adicional na Factory)
    @SqsListener(value = "${app.queues.payment-processing}", acknowledgementMode = "MANUAL")
    public void receivePaymentBatchManualAck(List<Message<Payment>> messages, Acknowledgement acknowledgement) {
        log.info("Recebido lote de {} mensagens com ACK manual.", messages.size());
        for (Message<Payment> message : messages) {
            Payment payment = message.getPayload();
            try {
                log.debug("Processando pagamento ID: {}", payment.getPaymentId());
                // ... lógica de processamento ...
                log.debug("Pagamento ID: {} processado com sucesso.", payment.getPaymentId());
                // Confirma apenas esta mensagem
                acknowledgement.acknowledge(message);
            } catch (Exception e) {
                log.error("Erro ao processar pagamento ID: {}. Não será confirmado (NACK implícito ou explícito).", payment.getPaymentId(), e);
                // Não chamar acknowledge() para esta mensagem fará com que ela retorne à fila.
                // acknowledgement.nack(message); // Poderia ser usado para NACK explícito se necessário
            }
        }
        log.info("Lote de {} mensagens processado com ACK manual.", messages.size());
    }
    */
}

