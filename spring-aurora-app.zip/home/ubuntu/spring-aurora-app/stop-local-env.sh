#!/bin/bash

echo "Parando LocalStack e MySQL com Docker Compose..."
docker-compose down

echo "Ambiente local parado."

