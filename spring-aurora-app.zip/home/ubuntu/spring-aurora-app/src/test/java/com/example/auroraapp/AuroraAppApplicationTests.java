package com.example.auroraapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuroraAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
